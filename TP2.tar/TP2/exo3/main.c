#include "math.h"

int main(int argc, char** argv)
{
	testBibliotheque();

	return 0;
}