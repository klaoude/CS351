#ifndef MATH_H
#define MATH_H

unsigned int quotient(unsigned int a, unsigned int b);
unsigned int reste(unsigned int a, unsigned int b);
unsigned int valeurAbsolue(int a);
unsigned int ppcm(unsigned int a, unsigned int b);

void testBibliotheque();

#endif